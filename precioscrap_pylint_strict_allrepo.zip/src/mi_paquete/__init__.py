from .aritmetica import suma, division_segura

__all__ = ["suma", "division_segura"]
